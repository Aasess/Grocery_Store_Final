﻿using Grocery_Store.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Globalization;
using System.Linq;

namespace Grocery_Store.Controllers
{
    public class CartController : Controller
    {
        private readonly GroceryDbContext _context;

        public CartController(GroceryDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var cart = GetCart();
            return View(cart);
        }

        [HttpPost]
        public IActionResult AddToCart(int id, int quantity)
        {
            var item = _context.Items.Include(i => i.Category).FirstOrDefault(i => i.Id == id);
            if (item == null) return NotFound();

            var cart = GetCart();
            cart.AddItem(item, quantity);
            SaveCart(cart);

            return RedirectToAction("Index");
        }

        public IActionResult RemoveFromCart(int id)
        {
            var cart = GetCart();
            cart.RemoveItem(id);
            SaveCart(cart);

            return RedirectToAction("Index");
        }

        public IActionResult Checkout()
        {
            var cart = GetCart();
            if (!cart.Items.Any())
            {
                return RedirectToAction("Index");
            }

            return View(new CheckoutViewModel());
        }

        [HttpPost]
        public IActionResult Checkout(CheckoutViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var cart = GetCart();

            var order = new Order
            {
                Name = model.Name,
                Email = model.Email,
                Address = model.Address,
                City = model.City,
                PostalCode = model.PostalCode,
                Phone = model.Phone,
                CreditCardNumber = model.CreditCardNumber,
                ExpirationDate = model.ExpirationDate,
                CVV = model.CVV,
                OrderItems = cart.Items.Select(i => new OrderItem
                {
                    ItemId = i.Item.Id,
                    Quantity = i.Quantity,
                    Price = i.Item.Price
                }).ToList()
            };

            _context.Orders.Add(order);
            _context.SaveChanges();

            // Clear the cart
            cart = new Cart();
            SaveCart(cart);

            return RedirectToAction("OrderConfirmation");
        }

        public IActionResult OrderConfirmation()
        {
            return View();
        }

        private Cart GetCart()
        {
            var cart = HttpContext.Session.Get<Cart>("Cart") ?? new Cart();
            return cart;
        }

        private void SaveCart(Cart cart)
        {
            HttpContext.Session.Set("Cart", cart);
        }
    }
}
